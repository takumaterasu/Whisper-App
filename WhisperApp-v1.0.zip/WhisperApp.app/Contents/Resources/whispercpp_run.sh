#!/bin/bash

# === WHISPER STANDALONE SCRIPT ===
# Standalone version that includes all necessary binaries

# === RELATIVE PATHS TO APPLICATION ===
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$(dirname "$SCRIPT_DIR")"
BIN_DIR="$APP_DIR/bin"
MODELS_DIR="$APP_DIR/models"

# === CONFIGURATION ===
MODEL="ggml-medium.bin"
MODEL_URL="https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin"
NOTIFICATION_TITLE="WhisperApp"
WHISPER_BIN="$BIN_DIR/whisper-cli"
FFMPEG_BIN="$BIN_DIR/ffmpeg"
MODEL_PATH="$MODELS_DIR/$MODEL"

# === MODEL DOWNLOAD FUNCTION ===
download_model() {
    echo "📥 Downloading Whisper model (first time use)..."
    echo "   This may take a few minutes (1.5 GB)..."
    
    mkdir -p "$MODELS_DIR"
    
    # Use curl with progress bar
    if command -v curl &> /dev/null; then
        curl -L --progress-bar "$MODEL_URL" -o "$MODEL_PATH.tmp"
        if [ $? -eq 0 ]; then
            mv "$MODEL_PATH.tmp" "$MODEL_PATH"
            echo "✅ Model downloaded successfully!"
        else
            echo "❌ Error during download"
            rm -f "$MODEL_PATH.tmp"
            exit 1
        fi
    else
        echo "❌ curl is not available to download the model"
        exit 1
    fi
}

# === BINARY VERIFICATION ===
if [ ! -f "$WHISPER_BIN" ]; then
    echo "❌ Whisper binary not found: $WHISPER_BIN"
    echo "   Application appears to be corrupted."
    exit 1
fi

if [ ! -f "$FFMPEG_BIN" ]; then
    echo "❌ FFmpeg binary not found: $FFMPEG_BIN"
    echo "   Application appears to be corrupted."
    exit 1
fi

# === MODEL VERIFICATION/DOWNLOAD ===
if [ ! -f "$MODEL_PATH" ]; then
    echo "🔍 Whisper model not found, automatic download..."
    download_model
fi

# === VIDEO FILE INPUT ===
if [ -n "$1" ]; then
    VIDEO="$1"
else
    echo "🎞️ Drag your video here and press Enter:"
    read -r VIDEO
fi

if [ ! -f "$VIDEO" ]; then
    echo "❌ File \"$VIDEO\" does not exist."
    exit 1
fi

# === EXTRACT FILE INFO ===
VIDEO_PATH=$(realpath "$VIDEO")
VIDEO_DIR=$(dirname "$VIDEO_PATH")
VIDEO_BASE=$(basename "$VIDEO_PATH")
FILENAME="${VIDEO_BASE%.*}"
AUDIO_FILE="$VIDEO_DIR/$FILENAME.wav"
OUT_PREFIX="$VIDEO_DIR/$FILENAME"

# === LANGUAGE CHOICE VIA PARAMETER ===
LANG_OPTION="$2"

# === VIDEO -> WAV CONVERSION ===
echo "🎧 Converting video to audio .wav..."
"$FFMPEG_BIN" -y -i "$VIDEO_PATH" -ar 16000 -ac 1 -c:a pcm_s16le "$AUDIO_FILE"

if [ $? -ne 0 ]; then
    echo "❌ Error during audio conversion"
    exit 1
fi

# === WHISPER PROCESSING ===
echo "🧠 Processing with Whisper..."

if [ "$LANG_OPTION" = "2" ]; then
    "$WHISPER_BIN" -m "$MODEL_PATH" \
        -f "$AUDIO_FILE" \
        -l fr \
        -tr \
        -otxt -osrt -ovtt \
        -of "$OUT_PREFIX"
else
    "$WHISPER_BIN" -m "$MODEL_PATH" \
        -f "$AUDIO_FILE" \
        -l en \
        -otxt -osrt -ovtt \
        -of "$OUT_PREFIX"
fi

if [ $? -ne 0 ]; then
    echo "❌ Error during Whisper processing"
    rm -f "$AUDIO_FILE"
    exit 1
fi

# === CLEANUP ===
rm -f "$AUDIO_FILE"

# === NOTIFICATION ===
osascript -e "display notification \"Subtitles generated successfully!\" with title \"$NOTIFICATION_TITLE\" subtitle \"$FILENAME.srt\""

# === PAUSE BEFORE CLOSING ===
sleep 1

# === CLOSE TERMINAL ===
osascript -e 'tell application "Terminal" to close (every window whose name contains "'"$FILENAME"'")' &> /dev/null || \
osascript -e 'tell application "Terminal" to close front window' &> /dev/null

echo "✅ Transcription completed! Generated files:"
echo "   📄 $OUT_PREFIX.txt"
echo "   🎬 $OUT_PREFIX.srt"
echo "   📺 $OUT_PREFIX.vtt"

exit 0 